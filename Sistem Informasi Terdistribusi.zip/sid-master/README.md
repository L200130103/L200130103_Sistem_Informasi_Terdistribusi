# sid
Sistem Informasi Terdistribusi
